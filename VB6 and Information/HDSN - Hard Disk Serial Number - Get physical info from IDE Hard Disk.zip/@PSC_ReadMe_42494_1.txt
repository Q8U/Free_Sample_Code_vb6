Title: HDSN - Hard Disk Serial Number - Get physical info from IDE Hard Disk
Description: The library get physical information (Model Number, Serial Number and Firmware Revision) of the IDE Hard disk (unit from 0 to 3) SMART compliant
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42494&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
