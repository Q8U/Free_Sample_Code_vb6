ICQ Control Center v1.0 (C) 2000 DIGITAL VAMPIRE
From the MAker of ic-crypt www.ic-crypt.org.uk.

-------------------------------------------------------------

a year of research and a few months later .....
it was time to translate it myself :)

-------------------------------------------------------------


Functions Implemented and custom made.

Get User LIST(Gets all ICQ online contacts and FULL details)

GetownerStatus(online offline etc etc owner status)
GetOwnerUIN(returns the icq owners uin)
GetOwnerIP(returns the icq owners IP ADDRESS)
GetOwnerNickName(returns the icq owners NIckname)
GetOwnerEmail(returns the icq owners e-mail address)

Send ICQ URL(launches and fills in the send url dialog)
Send ICQ MESSAGE (launches and fills in the send url dialog)

Send ICQ PAGER (sends an icq pager message using winsock)

ICQ NOTIFICATION FUNCTIONS fully implemented

ICQAPINotify_FileReceived(retrives filenames recieved in icq)

ICQAPINotify_OnlineListChange :  occours when

1. A user went online / offline.
2. Owner "Floats a user"
3. A user moved up / down in the list

ICQAPINotify_AppBarStateChange : returns if icq window is

0 - floating
1 - docked right
2 - docked left
3 - docked top
4 - docked bottom

GetDottedIP and PointerToString function.


Have Phun ------------------------------------------------

icqmapi.dll needs to be in windows\system directory

dv.  ICQ UIN:14996057

----------------------------------------------------------


