#ifndef __ICQAPIINTERFACE_H_
#define __ICQAPIINTERFACE_H_

#include "ICQAPICalls.h"
#include "ICQAPINotifications.h"


#endif	// __ICQAPIINTERFACE_H_
